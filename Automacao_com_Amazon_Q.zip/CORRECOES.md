# Correções aplicadas

Resumo das mudanças feitas a partir da revisão do projeto. Para você comparar
"antes vs depois" e entender o porquê de cada uma.

## 1. `VITE_API_URL` não estava sendo usado de fato no build do CodeBuild

**Problema:** o `Dockerfile` tinha a URL da API fixa (`https://labs.cloudopspro.tech`)
direto no `RUN`. O README dizia para configurar `VITE_API_URL` no projeto do
CodeBuild, mas o `buildspec` nunca repassava essa variável para o `docker build`
— então configurar a variável no CodeBuild não tinha efeito nenhum.

**Correção:**
- `Dockerfile`: a URL agora vem de um `ARG VITE_API_URL`, com o mesmo valor
  padrão de antes (então nada quebra se ninguém passar nada).
- `buildspec.yml` e `buildspec-dynamic.yml`: passam
  `--build-arg VITE_API_URL=$VITE_API_URL` no `docker build`, lendo da
  variável de ambiente do CodeBuild (com fallback pro valor padrão se ela não
  estiver definida).

Agora configurar `VITE_API_URL` no CodeBuild realmente muda a URL usada no
build do frontend.

## 2. `compose.yml` estava incompleto

**Problema:** o arquivo só tinha o bloco `environment` do serviço `server`,
mas o README instrui `docker compose up -d database` — e não existia nenhum
serviço `database` no arquivo.

**Correção:** `compose.yml` agora tem:
- Um serviço `database` (Postgres 16) com usuário/senha/banco padrão
  (`postgres`/`postgres`/`bia`), expondo a porta `5433` no host — que já é o
  valor padrão esperado por `config/database.js` quando você roda a app
  direto no host (`npm start`).
- Um serviço `server` opcional, que builda a imagem de produção
  (`Dockerfile`) localmente, já conectado ao `database` acima. O bloco para
  conectar a um RDS real via Secrets Manager continua disponível, só
  comentado — descomente se for esse o seu caso.

## 3. Zip do próprio repositório commitado na raiz

**Problema:** `Automacao_com_Amazon_Q-main_1.zip` (560 KB) estava versionado
na raiz do projeto — provavelmente um backup esquecido.

**Correção:** o arquivo foi removido e `*.zip` foi adicionado ao
`.gitignore` para evitar que isso aconteça de novo.

---

## O que **não** foi alterado (de propósito)

- A dependência `@aws-sdk/client-secrets-manager` no `package.json` foi
  mantida, mesmo a regra `infraestrutura.md` dizendo para não usar Secrets
  Manager nessa fase — é só uma inconsistência entre regra e código-base
  herdado do projeto original, não um bug funcional. Vale você decidir se
  quer remover a dependência ou atualizar a regra.
- `Dockerfile_checkdisponibilidade` e os scripts de `check-disponibilidade`
  não foram tocados — ainda não ficou claro o propósito exato deles; me diga
  se quiser que eu investigue.
